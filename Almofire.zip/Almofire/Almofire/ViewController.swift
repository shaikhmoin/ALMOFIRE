//
//  ViewController.swift
//  Almofire
//
//  Created by MACOS on 6/15/17.
//  Copyright © 2017 MACOS. All rights reserved.
//

import UIKit
import Alamofire

class ViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {

    @IBOutlet var tbl: UITableView!
    var final = [Any]()
    
    @IBOutlet var txtname: UITextField!
    @IBOutlet var txtadd: UITextField!
    @IBOutlet var txtmob: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        Alamofire.request("http://localhost/moin/select.php").responseJSON { response in
            print(response.request ?? "hj")  // original URL request
            print(response.response ?? "hg") // HTTP URL response
            print(response.data ?? "gf")     // server data
            print(response.result)   // result of response serialization
            
            if let JSON = response.result.value {
                print("JSON: \(JSON)")
                
                    do
                    {
                        let dt = try JSONSerialization.jsonObject(with: response.data!, options: []) as! [Any]
                        
                        for i in dt
                        {
                            self.final.append(i)
                            self.tbl.reloadData()
                            
                        }
                    }
                    catch
                    {
                        
                    }
                
            }
        }
    
    }

    @IBAction func btnInsert(_ sender: Any) {
        
        var paramiter :Parameters = [:]
        paramiter["Name"] = txtname.text
        paramiter["Address"] = txtadd.text
        paramiter["Mobile"] = txtmob.text
        
        Alamofire.request("http://localhost/moin/insert.php", method: .post, parameters: paramiter, encoding: URLEncoding.httpBody).responseString{ response in
            print(response.request ?? "hj")  // original URL request
            print(response.response ?? "hg") // HTTP URL response
            print(response.data ?? "gf")     // server data
            print(response.result)   // result of response serialization
            
            if let JSON = response.result.value {
                print("JSON: \(JSON)")
            }
        }

        
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return final.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell")
        
        let dicfinal = final[indexPath.row] as! [String:Any]
        cell?.textLabel?.text = dicfinal["Name"] as? String
        
        // Retrive image from database
        var img1:String = ""
        let path = dicfinal["image"] as! String
        let str = "http://localhost/Moin/" + path
        img1.append(str)
        
        let url = URL(string: str)
        
        do{
            let data = try Data(contentsOf: url!)
            //print(data)
            
            cell?.imageView?.image = UIImage(data: data)
            
            
        }
        catch
        {
            
        }

        return cell!
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}


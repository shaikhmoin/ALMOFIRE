<?php
    $con=new mysqli("localhost","root","","MyTest");
    
    $emp_name = $_REQUEST["Name"];
    $emp_add = $_REQUEST["Address"];
    $emp_mob = $_REQUEST["Mobile"];
    
    $query = "insert into EMP(Name,Address,Mobile)values('$emp_name','$emp_add','$emp_mob')";
    
    $con -> query($query);
    echo "success";
   

    
?>
